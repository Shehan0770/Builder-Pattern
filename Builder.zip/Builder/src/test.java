public class test {
    public static void main(String[] args) {
        User.Builder builder = new User.Builder(2000255002,"Shehan@gmail.com");
        builder.setName("Sheehan Malinda");
        builder.setMobile(112223334);

        User user = builder.build();

        System.out.println(user);
    }

}
